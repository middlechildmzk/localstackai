# Payment Link Setup

## Fastest launch setup

Use one of:
- Stripe Payment Links
- Gumroad
- Lemon Squeezy
- Calendly paid booking

## Products

### Product 1
Name:
The 2026 Revenue Recovery Blueprint: Plumbing Edition

Price:
$49 one-time

Description:
A practical guide to choosing the first AI receptionist, call tracking, CRM, review, and follow-up stack for a plumbing business.

### Product 2
Name:
Revenue Recovery Stack Audit

Price:
$99 one-time

Description:
A 15–20 minute review of your current phone, booking, CRM, review, and follow-up stack with a simple recommendation.

## Where to paste links

- `app/guide/page.tsx`
- `app/audit/page.tsx`
- `components/Calculator.tsx` success state
- `app/tools/[slug]/page.tsx` audit CTA

## Placeholder search terms

Search the codebase for:
- `Get the $49 Guide`
- `Request Audit`
- `Book the $99 Stack Audit`
- `mailto:dllarson1991@gmail.com`
