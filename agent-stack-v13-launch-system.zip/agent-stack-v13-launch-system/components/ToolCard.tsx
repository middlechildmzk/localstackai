import Link from "next/link";
import type { Tool } from "@/lib/types";

export function ToolCard({ tool }: { tool: Tool }) {
  return (
    <article className="card tool-card">
      <div className="tool-top">
        <div>
          <div className="tool-logo">{tool.initials}</div>
          <h3 style={{ marginTop: 12 }}>{tool.name}</h3>
          <span className="badge blue">{tool.categoryLabel}</span>
        </div>
        <span className={`badge ${tool.isVerified ? "green" : "warn"}`}>
          {tool.isVerified ? "Verified" : "Needs review"}
        </span>
      </div>

      <p>{tool.description}</p>

      <div className="badges">
        {tool.publicBadges.slice(0, 3).map((badge) => (
          <span key={badge} className="badge green">{badge}</span>
        ))}
      </div>

      <p className="small"><strong>Best for:</strong> {tool.bestForTags.join(", ")}</p>
      <p className="small muted"><strong>Works with:</strong> {tool.integrations.slice(0, 4).join(", ") || "Verify integrations"}</p>
      <p className="small muted"><strong>Pricing:</strong> {tool.pricingSummary}</p>
      <p className="small muted"><strong>{tool.pricingLastVerified}</strong></p>

      <div className="tool-actions">
        <Link className="btn primary" href={`/tools/${tool.slug}`}>View Profile</Link>
        <Link className="btn" href={`/go/${tool.slug}?source=tool-card`} rel="sponsored nofollow">Check Pricing</Link>
      </div>

      <p className="small muted">Disclosure: we may earn a commission from some links.</p>
    </article>
  );
}
