export function AffiliateDisclosure() {
  return (
    <div className="card warning">
      <strong>Affiliate disclosure:</strong>{" "}
      We recommend tools based on technical fit, setup difficulty, integrations, pricing clarity, and home-service revenue-recovery use cases.
      If you click some links, we may earn a commission at no extra cost to you.
    </div>
  );
}
