import Link from "next/link";

export function Header() {
  return (
    <header>
      <div className="container nav">
        <Link href="/" className="brand">
          <div className="logo">LS</div>
          <span>LocalStack AI</span>
        </Link>
        <nav className="links">
          <Link href="/tools">Tools</Link>
          <Link href="/for-plumbers">For Plumbers</Link>
          <Link href="/for-hvac">For HVAC</Link>
          <Link href="/best-ai-receptionist-for-plumbers">Money Page</Link>
          <Link href="/guide">Guide</Link>
          <Link href="/audit">Audit</Link>
          <Link href="/how-we-score">Trust</Link>
        </nav>
      </div>
    </header>
  );
}
