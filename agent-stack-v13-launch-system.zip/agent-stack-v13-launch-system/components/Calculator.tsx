"use client";

import { useMemo, useState } from "react";

const defaults: Record<string, number> = {
  plumbers: 650,
  hvac: 900,
  roofers: 2500,
  electricians: 500,
  cleaners: 250
};

export function CostOfSilenceCalculator() {
  const [vertical, setVertical] = useState("plumbers");
  const [averageJobValue, setAverageJobValue] = useState(defaults.plumbers);
  const [missedCalls, setMissedCalls] = useState(4);
  const [bookingRate, setBookingRate] = useState(0.3);
  const [email, setEmail] = useState("");
  const [captured, setCaptured] = useState(false);
  const [loading, setLoading] = useState(false);

  const result = useMemo(() => {
    const weekly = averageJobValue * missedCalls * bookingRate;
    const annual = weekly * 52;
    const monthly = annual / 12;
    return { weekly, annual, monthly };
  }, [averageJobValue, missedCalls, bookingRate]);

  function updateVertical(value: string) {
    setVertical(value);
    setAverageJobValue(defaults[value] || 650);
  }

  const recommended =
    missedCalls >= 5 ? "AI receptionist + CRM handoff" : missedCalls >= 2 ? "missed-call text-back + phone tracking" : "CRM + follow-up automation";

  async function capture() {
    if (!email.includes("@")) return alert("Enter an email to send the report.");
    setLoading(true);

    const response = await fetch("/api/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        businessType: vertical,
        biggestPain: "missed-calls",
        source: "cost-of-silence-calculator",
        recommendedStack: {
          recommended,
          averageJobValue,
          missedCalls,
          bookingRate,
          monthlyOpportunity: result.monthly,
          annualOpportunity: result.annual
        }
      })
    });

    setLoading(false);

    if (!response.ok) {
      alert("Could not save your report request. Try again.");
      return;
    }

    setCaptured(true);
  }

  return (
    <div className="grid2">
      <div className="card">
        <div className="eyebrow">Cost of Silence</div>
        <h2>How much opportunity are missed calls leaking?</h2>
        <p className="muted">This calculator uses your inputs to estimate missed-call opportunity. It is not a guarantee of recovered revenue.</p>

        <label>Business type</label>
        <select value={vertical} onChange={(e) => updateVertical(e.target.value)}>
          <option value="plumbers">Plumbing</option>
          <option value="hvac">HVAC</option>
          <option value="roofers">Roofing</option>
          <option value="electricians">Electrical</option>
          <option value="cleaners">Cleaning</option>
        </select>

        <label>Average job value ($)</label>
        <input type="number" value={averageJobValue} min={0} onChange={(e) => setAverageJobValue(Number(e.target.value))} />

        <label>Missed calls per week</label>
        <input type="number" value={missedCalls} min={0} onChange={(e) => setMissedCalls(Number(e.target.value))} />

        <label>Estimated booking rate</label>
        <select value={bookingRate} onChange={(e) => setBookingRate(Number(e.target.value))}>
          <option value={0.3}>Conservative: 30%</option>
          <option value={0.5}>Aggressive: 50%</option>
        </select>
      </div>

      <div className="card">
        <h3>Estimated missed-call opportunity</h3>
        <p className="muted">Monthly</p>
        <div className="big-number">{result.monthly.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 })}</div>

        <p className="muted">Annual</p>
        <div className="big-number">{result.annual.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 })}</div>

        <div className="result">
          <strong>Recommended first fix:</strong> {recommended}. This is an estimated opportunity based on your inputs, not guaranteed recovered revenue.
        </div>

        <div className="leadbox">
          <input type="email" placeholder="Email to send my free report" value={email} onChange={(e) => setEmail(e.target.value)} />
          <button className="btn primary" onClick={capture} disabled={loading}>{loading ? "Sending..." : "Send My Free Report"}</button>
        </div>

        {captured && (
          <div className="result">
            <strong>Report requested.</strong> Next: compare your recommended stack, then consider the $49 Blueprint or $99 Stack Audit.
          </div>
        )}
      </div>
    </div>
  );
}
