# First Traffic Playbook

Goal: first 100 targeted visitors, first 10 emails, first affiliate clicks, first audit/guide interest.

## Target URL

Start with:

`/for-plumbers`

Then:

`/for-hvac`

## Message to local contractor

Hey [Name] — I’m building LocalStack AI, a free tool that helps plumbing/HVAC owners estimate how much revenue missed calls might be leaking and which AI receptionist or follow-up stack to install first. Could I send you the plumber version and get your honest feedback?

## LinkedIn post

Home service owners lose money in the least glamorous way possible:

They miss the call.

Not because they’re bad operators — because they’re under a sink, in an attic, on a roof, or driving to the next job.

I built a quick calculator for plumbers and HVAC companies to estimate missed-call opportunity and compare tools like AI receptionists, call tracking, CRMs, and review automation.

Starting with plumbers:
[YOUR /for-plumbers URL]

I’d love feedback from anyone who runs or works with a home service business.

## Vendor outreach

Hey [Name] — I’m building LocalStack AI, a focused recommendation database for plumbing/HVAC owners comparing AI receptionists, phone tools, CRMs, and review automation.

We included [Tool] in our launch set because it appears relevant for [use case]. Do you have an official partner/referral program or preferred pricing/docs link we should use?

## Daily launch tasks

Day 1:
- Send to 10 local plumbers/HVAC owners.
- Send to 5 vendors.
- Post once on LinkedIn.

Day 2:
- Send to 20 more owners.
- DM 5 consultants/agencies serving trades.
- Check Supabase clicks/leads.

Day 3:
- Improve copy based on objections.
- Publish one comparison page.
- Push second LinkedIn post.
