# Version Roadmap: v1.3 → v2

## v1.3 — Deployment System + Launch Ops
Status: this package.

Includes:
- Supabase schema + seed SQL
- Vercel deployment runbook
- env verification
- lead capture endpoint
- click tracking hooks
- first traffic playbook
- GitHub Actions CI/nightly checks

## v1.4 — Supabase Live Data
Goal:
Move from hardcoded `lib/tools.ts` to Supabase-backed data fetching.

Build:
- Server data fetchers
- Supabase-backed `/tools`
- Supabase-backed `/tools/[slug]`
- Admin-only seed/update workflow
- Public-safe API responses

## v1.5 — Conversion Funnel
Goal:
Turn traffic into emails, guide sales, and audit requests.

Build:
- Email delivery via Resend/Loops/ConvertKit
- Guide checkout link
- Audit checkout + scheduling link
- Thank-you page personalization
- Calculator result email template
- PostHog/Vercel Analytics events

## v1.6 — Money Pages + Internal Linking
Goal:
Improve SEO/GEO cluster.

Build:
- `/jobber-vs-housecall-pro`
- `/smith-ai-vs-ruby`
- `/podium-vs-nicejob`
- FAQ blocks + FAQPage JSON-LD
- Breadcrumbs for Home > Verticals > HVAC > CRM

## v1.7 — Recommendation Engine
Goal:
Make Stack Builder feel prescriptive.

Build:
- Rule-based scoring by vertical + pain
- 2-tool/3-tool recommended stacks
- “Start here” recommendation
- Budget-aware ranking
- Avoid-if logic

## v1.8 — Content Queue
Goal:
Let the site expand safely while you sleep.

Build:
- Supabase `content_queue`
- Draft page generator
- Status: draft/review/published
- Evidence-required gate
- Nightly workflow creates drafts only, never auto-publishes

## v1.9 — Vendor/Partner Ops
Goal:
Monetize better.

Build:
- Vendor outreach tracker
- Partner status dashboard
- Approved affiliate destination manager
- Sponsored placement label system
- Public “sponsored vs recommended” rules

## v2.0 — LocalStack AI Decision Engine
Goal:
Become the G2/Product Hunt-style decision layer for local service AI stacks.

Build:
- Supabase-backed dynamic content
- Search/filter powered by DB
- Stack Builder Quiz
- Saved stack PDF/report generation
- Guide/audit funnel
- More verticals only after plumbers/HVAC convert
- Optional vector search later
