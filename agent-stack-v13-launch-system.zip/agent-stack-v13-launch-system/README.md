# Agent-Stack v1.3 — Launch System

Public brand: **LocalStack AI**  
Internal engine: **Agent-Stack**

## What v1.3 adds

- Deployment runbook for Supabase + Vercel
- Supabase Launch 10 seed SQL
- Env verification script
- Local health script
- `/api/health`
- `/thank-you`
- First traffic playbook
- Stripe/audit link setup guide
- Version roadmap v1.3 → v2
- Next AI build prompt for v1.4
- CI + nightly workflows

## Run locally

```bash
npm install
cp .env.example .env.local
npm run verify-env
npm run typecheck
npm run build
npm run dev
```

## Main files to read

- `DEPLOYMENT_RUNBOOK.md`
- `FIRST_TRAFFIC_PLAYBOOK.md`
- `STRIPE_AND_AUDIT_LINKS.md`
- `VERSION_ROADMAP_V13_TO_V2.md`
- `CONTINUOUS_BUILD_SETUP.md`
- `NEXT_BUILD_PROMPT_V14.md`

## Supabase

Run these in order:

1. `supabase/schema.sql`
2. `supabase/seed_launch_10.sql`

## Fastest public launch

1. Create Supabase.
2. Run schema + seed.
3. Push repo to GitHub.
4. Import repo into Vercel.
5. Add env vars.
6. Deploy.
7. Add real Stripe/Gumroad/Calendly links.
8. Send first traffic to `/for-plumbers`.
