-- Agent-Stack / LocalStack AI Launch 10 seed data
-- Run after supabase/schema.sql.
-- This seed keeps affiliate payout data private. Add approved partner URLs later in affiliate_data.

insert into categories (slug, name, description, priority) values
('ai-receptionist', 'AI Receptionist', '24/7 call answering, lead intake, emergency routing, and booking support.', 'High'),
('missed-call-text', 'Missed Call Text-Back', 'Automatically text leads when you miss a call and route them into follow-up.', 'High'),
('field-service-crm', 'Field Service CRM', 'Scheduling, dispatch, payments, customer records, and job management.', 'High'),
('review-automation', 'Review Automation', 'Request reviews and build local trust after completed jobs.', 'Medium'),
('voip-phone', 'Business Phone / VoIP', 'Smart phone systems for teams, crews, and shared business numbers.', 'Medium')
on conflict (slug) do update set
  name = excluded.name,
  description = excluded.description,
  priority = excluded.priority,
  updated_at = now();

-- Minimal launch seed. Full detail still lives in lib/tools.ts for v1.3.
insert into tools (name, slug, category_slug, description, website_url, pricing_summary, pricing_last_verified, setup_difficulty, integrations, best_for_tags, verticals, partner_status, is_verified, is_draft)
values
('Smith.ai','smith-ai','ai-receptionist','AI and human receptionist service for businesses that need call answering, intake, scheduling, and lead qualification.','https://smith.ai/','AI Receptionist plans start at $95/mo; higher-volume AI plans and human receptionist options cost more.','Last checked May 11, 2026','Medium','["Zapier","Calendly","HubSpot","Google Calendar"]','["hybrid human/AI support","lead qualification","after-hours calls"]','["plumbers","electricians","hvac"]','apply',true,false),
('Ruby','ruby','ai-receptionist','Virtual receptionist service for businesses that want live call handling, a polished brand experience, and call overflow support.','https://www.ruby.com/','Ruby help docs list Call Ruby 50 at $250/mo for 50 receptionist minutes; official plan pages may show bundled variants.','Last checked May 11, 2026','Hard','["Jobber","Salesforce"]','["premium brand experience","live reception","call overflow"]','["hvac","plumbers"]','research',true,false),
('Podium','podium','review-automation','Messaging and reputation platform for local businesses that need SMS follow-up, reviews, and customer communication.','https://www.podium.com/','Quote-based / contact sales on Podium’s official pricing page; third-party pricing reports vary.','Last checked May 11, 2026','Medium','["Jobber","ServiceTitan","QuickBooks"]','["review growth","text messaging","lead recovery"]','["all"]','research',true,false),
('NiceJob','nicejob','review-automation','NiceJob helps businesses request reviews, showcase social proof, and improve reputation marketing.','https://nicejob.com/','NiceJob promotes a free trial; verify current paid plan pricing directly before quoting exact monthly cost.','Last checked May 11, 2026','Easy','["Jobber","Housecall Pro","Zapier"]','["easy review requests","social proof","review automation"]','["plumbers","hvac","roofers","cleaners"]','research',true,false),
('Jobber','jobber','field-service-crm','Jobber helps small home-service teams manage quoting, scheduling, invoices, payments, and customer communication.','https://getjobber.com/','Core starts at $49/mo month-to-month; annual or promotional pricing may be lower.','Last checked May 11, 2026','Easy','["Stripe","QuickBooks","Mailchimp","Zapier"]','["ease of use","mobile invoicing","small crews"]','["cleaners","electricians","plumbers","hvac"]','apply',true,false),
('Housecall Pro','housecall-pro','field-service-crm','Home service software for scheduling, dispatching, estimates, payments, reviews, and marketing workflows.','https://www.housecallpro.com/','Official pricing page says plans start from $59/mo; billing and plan details vary.','Last checked May 11, 2026','Medium','["Google Local Services Ads","QuickBooks","Google Calendar","Zapier"]','["integrated marketing","booking","mid-market growth"]','["plumbers","hvac","roofers"]','apply',true,false),
('ServiceTitan','servicetitan','field-service-crm','Field service platform for larger contractors that need dispatch, CRM, reporting, call booking, and operations management.','https://www.servicetitan.com/','Quote-based / request pricing. Best evaluated directly for larger operations.','Last checked May 11, 2026','Hard','["Direct GPS","Inventory Systems","Call booking"]','["enterprise reporting","large fleets","dispatch-heavy operations"]','["hvac","plumbers"]','research',true,false),
('CallRail','callrail','missed-call-text','CallRail helps businesses track calls, understand lead sources, and improve phone-driven marketing workflows.','https://www.callrail.com/','Lead Tracking starts at $55/mo; Voice Assist starts at $95/mo and requires Lead Tracking.','Last checked May 11, 2026','Medium','["Google Ads","Google Analytics","HubSpot","Zapier"]','["call tracking","lead attribution","missed-call visibility"]','["plumbers","hvac"]','research',true,false),
('Quo / OpenPhone','openphone','voip-phone','Quo, formerly OpenPhone, is a business phone system for teams that want shared numbers, texting, call history, and collaboration.','https://www.quo.com/','Starter is listed at $15/user/mo annually or $19/user/mo monthly.','Last checked May 11, 2026','Easy','["Zapier","Google Workspace","HubSpot","Slack"]','["shared team numbers","small crews","texting"]','["all"]','research',true,false),
('LeadConnector / GoHighLevel','gohighlevel','missed-call-text','GoHighLevel-style workflows are often used by agencies and operators for missed-call text-back, SMS/email follow-up, funnels, and local business automation.','https://www.gohighlevel.com/','Agency Starter is $97/mo; email/SMS/phone usage and other add-ons can create extra costs.','Last checked May 11, 2026','Hard','["Twilio","Stripe","Zapier","Calendars"]','["missed-call text-back","automation-heavy setup","agency workflows"]','["all"]','research',true,false)
on conflict (slug) do update set
  name = excluded.name,
  category_slug = excluded.category_slug,
  description = excluded.description,
  website_url = excluded.website_url,
  pricing_summary = excluded.pricing_summary,
  pricing_last_verified = excluded.pricing_last_verified,
  setup_difficulty = excluded.setup_difficulty,
  integrations = excluded.integrations,
  best_for_tags = excluded.best_for_tags,
  verticals = excluded.verticals,
  partner_status = excluded.partner_status,
  is_verified = excluded.is_verified,
  is_draft = excluded.is_draft,
  updated_at = now();

insert into affiliate_data (tool_id, raw_affiliate_url, network, internal_notes, is_active)
select id, website_url, 'direct', 'Replace with approved affiliate link when available.', true
from tools
where slug in ('smith-ai','ruby','podium','nicejob','jobber','housecall-pro','servicetitan','callrail','openphone','gohighlevel');
