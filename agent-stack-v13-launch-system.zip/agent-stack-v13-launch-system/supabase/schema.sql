-- Agent-Stack / LocalStack AI V1 Supabase Schema
-- Keep public tool metadata separate from private affiliate economics.

create extension if not exists "uuid-ossp";

create table if not exists categories (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  name text not null,
  description text,
  priority text check (priority in ('High', 'Medium', 'Low')) default 'Medium',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists tools (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  category_slug text references categories(slug),
  description text,
  tagline text,
  answer_box text,
  logo_url text,
  website_url text,
  pricing_summary text,
  pricing_last_verified text,
  setup_difficulty text check (setup_difficulty in ('Easy', 'Medium', 'Hard')),
  integrations jsonb default '[]'::jsonb,
  best_for_tags jsonb default '[]'::jsonb,
  verticals jsonb default '[]'::jsonb,
  features jsonb default '[]'::jsonb,
  avoid_if text,
  evidence_links jsonb default '[]'::jsonb,
  alternatives jsonb default '[]'::jsonb,
  public_badges jsonb default '[]'::jsonb,
  partner_status text check (partner_status in ('active', 'apply', 'research', 'unavailable')) default 'research',
  is_featured boolean default false,
  public_status text default 'published',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Private affiliate data. Do not expose through public API.
create table if not exists affiliate_data (
  id uuid primary key default uuid_generate_v4(),
  tool_id uuid references tools(id) on delete cascade,
  raw_affiliate_url text not null,
  payout_terms text,
  network text,
  special_offer_code text,
  internal_notes text,
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists outbound_clicks (
  id uuid primary key default uuid_generate_v4(),
  tool_id uuid references tools(id) on delete set null,
  vertical_context text,
  source_page text,
  referrer text,
  user_agent text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  clicked_at timestamptz default now()
);

create table if not exists quiz_leads (
  id uuid primary key default uuid_generate_v4(),
  email text,
  business_type text,
  biggest_pain text,
  current_tools text[],
  monthly_budget text,
  recommended_stack_json jsonb,
  created_at timestamptz default now()
);

create table if not exists calculator_events (
  id uuid primary key default uuid_generate_v4(),
  email text,
  vertical_slug text,
  average_job_value numeric,
  missed_calls_per_week numeric,
  booking_rate numeric,
  estimated_monthly_leak numeric,
  estimated_annual_leak numeric,
  recommended_category text,
  created_at timestamptz default now()
);

create table if not exists tool_search_events (
  id uuid primary key default uuid_generate_v4(),
  query text,
  filters_json jsonb,
  clicked_tool_slug text,
  created_at timestamptz default now()
);

alter table categories enable row level security;
alter table tools enable row level security;
alter table affiliate_data enable row level security;
alter table outbound_clicks enable row level security;
alter table quiz_leads enable row level security;
alter table calculator_events enable row level security;
alter table tool_search_events enable row level security;

create policy "Public read categories" on categories for select using (true);
create policy "Public read published tools" on tools for select using (public_status = 'published');

-- affiliate_data should have no public read policy.
-- Use service role / server-only access for /go/[slug] route.

-- Optional insert policies for anonymous tracking can be added later through Edge Functions or server routes.


-- V1.2 additions
alter table tools add column if not exists pricing_source_url text;
alter table tools add column if not exists pricing_last_verified text;
alter table tools add column if not exists is_verified boolean default false;
alter table tools add column if not exists is_draft boolean default false;
alter table tools add column if not exists pros_cons jsonb default '{}'::jsonb;
alter table tools add column if not exists vertical_fit_notes jsonb default '{}'::jsonb;

create table if not exists guide_purchases (
  id uuid primary key default uuid_generate_v4(),
  email text,
  product_slug text,
  amount_cents integer,
  provider text,
  provider_session_id text,
  created_at timestamptz default now()
);

alter table guide_purchases enable row level security;
