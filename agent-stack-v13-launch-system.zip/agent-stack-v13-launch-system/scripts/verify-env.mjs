const requiredForDeploy = ["NEXT_PUBLIC_SITE_URL"];
const optionalButRecommended = [
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_ANON_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
  "STRIPE_SECRET_KEY"
];

let failed = false;

for (const key of requiredForDeploy) {
  if (!process.env[key]) {
    console.error(`Missing required env var: ${key}`);
    failed = true;
  } else {
    console.log(`✅ ${key}`);
  }
}

for (const key of optionalButRecommended) {
  if (!process.env[key]) {
    console.warn(`⚠️  Missing recommended env var: ${key}`);
  } else {
    console.log(`✅ ${key}`);
  }
}

if (failed) process.exit(1);
console.log("Environment check complete.");
