import http from "node:http";
import { spawn } from "node:child_process";

const routes = [
  "/",
  "/tools",
  "/tools/smith-ai",
  "/for-plumbers",
  "/for-hvac",
  "/how-we-score",
  "/how-we-make-money",
  "/guide",
  "/audit",
  "/api/tools",
  "/api/recommendations/plumbers/ai-receptionist"
];

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function get(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`http://127.0.0.1:3000${path}`, (res) => {
      res.resume();
      res.on("end", () => resolve(res.statusCode));
    });
    req.on("error", reject);
  });
}

const server = spawn("npm", ["run", "start"], {
  stdio: ["ignore", "pipe", "pipe"],
  shell: true
});

await wait(3000);

let failed = false;
for (const route of routes) {
  try {
    const status = await get(route);
    console.log(`${route}: ${status}`);
    if (!status || status >= 400) failed = true;
  } catch (error) {
    console.error(`${route}: ERROR`, error.message);
    failed = true;
  }
}

server.kill("SIGTERM");

if (failed) process.exit(1);
