import http from "node:http";

const routes = [
  "/",
  "/tools",
  "/tools/smith-ai",
  "/for-plumbers",
  "/for-hvac",
  "/guide",
  "/audit",
  "/how-we-score",
  "/how-we-make-money",
  "/sitemap.xml",
  "/robots.txt",
  "/api/health",
  "/api/tools"
];

function get(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`http://127.0.0.1:3000${path}`, (res) => {
      res.resume();
      res.on("end", () => resolve(res.statusCode));
    });
    req.on("error", reject);
  });
}

let failed = false;
for (const route of routes) {
  try {
    const status = await get(route);
    console.log(`${route}: ${status}`);
    if (!status || status >= 400) failed = true;
  } catch (error) {
    console.error(`${route}: ERROR`, error.message);
    failed = true;
  }
}

if (failed) process.exit(1);
console.log("Local health check passed.");
