import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const outDir = path.join(root, "public", "data");
fs.mkdirSync(outDir, { recursive: true });

// Lightweight static snapshot placeholder.
// In production, replace this with a Supabase export or import from lib/tools via tsx.
const snapshot = {
  generatedAt: new Date().toISOString(),
  note: "Run after build/deploy to publish public-safe tool data snapshots.",
  endpoints: ["/api/tools", "/api/recommendations/plumbers/ai-receptionist"]
};

fs.writeFileSync(path.join(outDir, "snapshot.json"), JSON.stringify(snapshot, null, 2));
console.log("Wrote public/data/snapshot.json");
