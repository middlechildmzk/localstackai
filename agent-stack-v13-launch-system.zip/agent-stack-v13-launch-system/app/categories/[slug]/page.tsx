import Link from "next/link";
import { notFound } from "next/navigation";
import { JsonLd } from "@/components/JsonLd";
import { ToolCard } from "@/components/ToolCard";
import { breadcrumbJsonLd, itemListJsonLd } from "@/lib/seo";
import { getCategory, getToolsByCategory, siteUrl, categories } from "@/lib/tools";

export function generateStaticParams() {
  return categories.map((category) => ({ slug: category.slug }));
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const category = getCategory(slug);
  if (!category) notFound();

  const categoryTools = getToolsByCategory(category.slug);

  return (
    <main>
      <JsonLd
        data={breadcrumbJsonLd([
          { name: "Home", url: siteUrl },
          { name: "Categories", url: `${siteUrl}/tools` },
          { name: category.name, url: `${siteUrl}/categories/${category.slug}` }
        ])}
      />
      <JsonLd
        data={itemListJsonLd(categoryTools.map((tool) => ({
          name: tool.name,
          url: `${siteUrl}/tools/${tool.slug}`,
          description: tool.description
        })))}
      />

      <section className="hero">
        <div className="container">
          <div className="eyebrow">Category</div>
          <h1>{category.name} for Home Service Businesses</h1>
          <p className="lead">{category.description}</p>
          <div className="hero-actions">
            <Link href="/tools" className="btn">Back to tools</Link>
            <Link href="/for-plumbers" className="btn primary">See plumber stack</Link>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> {category.name} tools help home-service businesses reduce missed leads, respond faster, and create cleaner handoffs into booking, CRM, reviews, or follow-up workflows.
          </div>

          <div className="tools-grid" style={{ marginTop: 16 }}>
            {categoryTools.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
        </div>
      </section>
    </main>
  );
}
