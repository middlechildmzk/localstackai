import type { MetadataRoute } from "next";
import { categories, siteUrl, tools } from "@/lib/tools";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  const staticRoutes = [
    "",
    "/tools",
    "/for-plumbers",
    "/for-hvac",
    "/best-ai-receptionist-for-plumbers",
    "/best-ai-receptionist-for-hvac",
    "/best-missed-call-text-back-for-plumbers",
    "/best-review-automation-for-plumbers",
    "/best-crm-for-hvac",
    "/how-we-score",
    "/how-we-make-money",
    "/guide",
    "/audit"
  ];

  return [
    ...staticRoutes.map((route) => ({
      url: `${siteUrl}${route}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: route === "" ? 1 : 0.8
    })),
    ...tools.map((tool) => ({
      url: `${siteUrl}/tools/${tool.slug}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: 0.7
    })),
    ...categories.map((category) => ({
      url: `${siteUrl}/categories/${category.slug}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: 0.6
    }))
  ];
}
