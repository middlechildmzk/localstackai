import Link from "next/link";
import { ToolCard } from "@/components/ToolCard";
import { CostOfSilenceCalculator } from "@/components/Calculator";
import { getToolsByVertical } from "@/lib/tools";

export default function ForHvacPage() {
  const recommended = getToolsByVertical("hvac").slice(0, 6);

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">For HVAC companies</div>
          <h1>Capture HVAC calls during seasonal surges and after hours.</h1>
          <p className="lead">Find AI receptionists, missed-call recovery tools, field service CRMs, and review platforms for HVAC teams.</p>
          <div className="hero-actions">
            <Link href="/best-ai-receptionist-for-hvac" className="btn primary">Best AI Receptionists</Link>
            <Link href="/tools" className="btn">Search Tools</Link>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> For HVAC companies, missed-call recovery matters most during seasonal demand spikes and after-hours emergency calls. Start with AI answering or text-back, then connect qualified leads to CRM and scheduling workflows.
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <CostOfSilenceCalculator />
        </div>
      </section>

      <section>
        <div className="container">
          <h2>Recommended HVAC stack</h2>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {recommended.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
        </div>
      </section>
      <section>
        <div className="container card">
          <h2>Related buyer guides</h2>
          <div className="badges">
            <a className="badge blue" href="/best-ai-receptionist-for-plumbers">Best AI receptionist for plumbers</a>
            <a className="badge blue" href="/best-ai-receptionist-for-hvac">Best AI receptionist for HVAC</a>
            <a className="badge blue" href="/best-missed-call-text-back-for-plumbers">Best missed-call text-back for plumbers</a>
            <a className="badge blue" href="/best-crm-for-hvac">Best CRM for HVAC</a>
            <a className="badge blue" href="/guide">Revenue Recovery Blueprint</a>
          </div>
        </div>
      </section>

    </main>
  );
}
