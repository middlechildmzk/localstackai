import { ToolCard } from "@/components/ToolCard";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { getRecommendedTools } from "@/lib/tools";

export default function BestReviewAutomationForPlumbers() {
  const picks = getRecommendedTools("plumbers", "review-automation");

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Best review automation for plumbers</div>
          <h1>Best Review Automation Tools for Plumbers</h1>
          <p className="lead">Compare tools that help plumbing companies request more Google reviews, follow up with customers, and build local trust.</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> For plumbers, review automation works best after call capture and booking are already handled. Podium and NiceJob are useful options to compare because they support customer messaging, review requests, and reputation workflows.
          </div>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {picks.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
          <div style={{ marginTop: 16 }}><AffiliateDisclosure /></div>
        </div>
      </section>
    </main>
  );
}
