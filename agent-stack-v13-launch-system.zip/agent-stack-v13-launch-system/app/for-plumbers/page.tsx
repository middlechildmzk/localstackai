import Link from "next/link";
import { ToolCard } from "@/components/ToolCard";
import { CostOfSilenceCalculator } from "@/components/Calculator";
import { getToolsByVertical } from "@/lib/tools";

export default function ForPlumbersPage() {
  const recommended = getToolsByVertical("plumbers").slice(0, 6);

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">For plumbers</div>
          <h1>Stop losing plumbing jobs to missed calls.</h1>
          <p className="lead">Find the AI receptionist, missed-call text-back, CRM, and review stack that helps plumbing companies capture emergency calls and book more work.</p>
          <div className="hero-actions">
            <Link href="/best-ai-receptionist-for-plumbers" className="btn primary">Best AI Receptionists</Link>
            <Link href="/tools" className="btn">Search Tools</Link>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> For most plumbing companies, the fastest revenue-recovery upgrade is an AI receptionist or missed-call text-back tool paired with a booking or CRM system. Start with call capture, then add follow-up and review automation.
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <CostOfSilenceCalculator />
        </div>
      </section>

      <section>
        <div className="container">
          <h2>Recommended plumber stack</h2>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {recommended.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
        </div>
      </section>
      <section>
        <div className="container card">
          <h2>Related buyer guides</h2>
          <div className="badges">
            <a className="badge blue" href="/best-ai-receptionist-for-plumbers">Best AI receptionist for plumbers</a>
            <a className="badge blue" href="/best-ai-receptionist-for-hvac">Best AI receptionist for HVAC</a>
            <a className="badge blue" href="/best-missed-call-text-back-for-plumbers">Best missed-call text-back for plumbers</a>
            <a className="badge blue" href="/best-crm-for-hvac">Best CRM for HVAC</a>
            <a className="badge blue" href="/guide">Revenue Recovery Blueprint</a>
          </div>
        </div>
      </section>

    </main>
  );
}
