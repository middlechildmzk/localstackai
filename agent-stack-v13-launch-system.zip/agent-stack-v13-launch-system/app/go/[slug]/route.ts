import { NextRequest, NextResponse } from "next/server";
import { getTool } from "@/lib/tools";
import { logOutboundClick } from "@/lib/tracking";

/**
 * Server-side redirect route.
 * Production:
 * - private affiliate destinations should come from Supabase `affiliate_data`
 * - this fallback redirects to public websiteUrl until partner links are approved
 */
export async function GET(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const tool = getTool(slug);

  if (!tool) {
    return NextResponse.redirect(new URL("/tools", request.url));
  }

  await logOutboundClick({
    toolSlug: tool.slug,
    verticalContext: request.nextUrl.searchParams.get("vertical") || "general",
    sourcePage: request.nextUrl.searchParams.get("source") || request.headers.get("referer") || null,
    referrer: request.headers.get("referer"),
    userAgent: request.headers.get("user-agent"),
    utmSource: request.nextUrl.searchParams.get("utm_source"),
    utmMedium: request.nextUrl.searchParams.get("utm_medium"),
    utmCampaign: request.nextUrl.searchParams.get("utm_campaign")
  });

  return NextResponse.redirect(tool.websiteUrl, 302);
}
