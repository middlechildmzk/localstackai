export default function HowWeMakeMoneyPage() {
  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Disclosure</div>
          <h1>How We Make Money</h1>
          <p className="lead">LocalStack AI may earn a commission when visitors sign up through certain partner links. This helps keep the database free to use.</p>
        </div>
      </section>

      <section>
        <div className="container grid2">
          <div className="card">
            <h2>Affiliate links</h2>
            <p>Some tool links route through `/go/[slug]` so we can track outbound clicks and redirect visitors to a vendor or partner page. We may earn a commission at no extra cost to you.</p>
          </div>

          <div className="card">
            <h2>Editorial separation</h2>
            <p>Recommendations should be based on home-service fit, revenue-recovery use case, setup difficulty, pricing clarity, integrations, and public evidence — not just payout.</p>
          </div>

          <div className="card warning">
            <h2>Sponsored placements</h2>
            <p>If we add sponsored placements later, they should be clearly labeled and separated from editorial recommendations.</p>
          </div>

          <div className="card">
            <h2>Private data</h2>
            <p>Private payout terms, raw affiliate URLs, vendor notes, and internal tracking details should not be exposed in public APIs or pages.</p>
          </div>
        </div>
      </section>
    </main>
  );
}
