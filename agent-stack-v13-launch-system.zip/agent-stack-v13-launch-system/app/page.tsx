import Link from "next/link";
import { tools } from "@/lib/tools";
import { CostOfSilenceCalculator } from "@/components/Calculator";

export default function HomePage() {
  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Home service revenue recovery database</div>
          <h1>Stop losing jobs to missed calls.</h1>
          <p className="lead">
            Search the AI tools and software stacks that help plumbers, HVAC companies, roofers, electricians, and cleaners answer more calls, recover more leads, and book more jobs.
          </p>
          <div className="hero-actions">
            <Link className="btn primary" href="/tools">Search Tool Database</Link>
            <Link className="btn" href="/for-plumbers">For Plumbers</Link>
            <Link className="btn" href="/for-hvac">For HVAC</Link>
          </div>
          <div className="statrow">
            <div className="stat"><b>{tools.length}</b><span className="muted">indexed tools</span></div>
            <div className="stat"><b>5</b><span className="muted">tool categories</span></div>
            <div className="stat"><b>2</b><span className="muted">launch verticals</span></div>
          </div>
        </div>
      </section>

      <section>
        <div className="container grid">
          <div className="card"><h3>Not another AI directory</h3><p>Tools are organized around actual owner problems: missed calls, slow booking, weak reviews, and follow-up gaps.</p></div>
          <div className="card"><h3>Built for search + AI answers</h3><p>Each tool has category, vertical, pricing, feature, integration, alternative, and evidence fields ready for structured pages and JSON endpoints.</p></div>
          <div className="card"><h3>Affiliate-safe by design</h3><p>Public pages show useful tool intelligence. Private fields track affiliate URLs, payout notes, and partner status.</p></div>
        </div>
      </section>

      <section>
        <div className="container">
          <CostOfSilenceCalculator />
        </div>
      </section>
    </main>
  );
}
