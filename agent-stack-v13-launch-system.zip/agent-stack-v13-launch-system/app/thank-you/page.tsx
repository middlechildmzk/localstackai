import Link from "next/link";

export default function ThankYouPage() {
  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Next Step</div>
          <h1>Your Revenue Recovery Report request is in.</h1>
          <p className="lead">While the automated email flow is being connected, use these next steps to compare tools and pick your first recovery stack.</p>
          <div className="hero-actions">
            <Link className="btn primary" href="/best-ai-receptionist-for-plumbers">Compare AI Receptionists</Link>
            <Link className="btn" href="/audit">Book a Stack Audit</Link>
            <Link className="btn" href="/guide">Get the Blueprint</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
