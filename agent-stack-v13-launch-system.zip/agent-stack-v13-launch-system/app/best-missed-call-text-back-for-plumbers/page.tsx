import { ToolCard } from "@/components/ToolCard";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { getRecommendedTools } from "@/lib/tools";

export default function BestMissedCallTextBackForPlumbers() {
  const picks = getRecommendedTools("plumbers", "missed-call-text");

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Best missed-call text-back for plumbers</div>
          <h1>Best Missed-Call Text-Back Tools for Plumbers</h1>
          <p className="lead">Find tools that automatically text plumbing leads when a call is missed and route them into follow-up.</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> Missed-call text-back is a strong first fix for plumbers who miss calls while on jobs but do not need a full AI receptionist yet. The best option depends on current CRM, budget, and automation comfort.
          </div>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {picks.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
          <div style={{ marginTop: 16 }}><AffiliateDisclosure /></div>
        </div>
      </section>
    </main>
  );
}
