import { ToolCard } from "@/components/ToolCard";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { getRecommendedTools } from "@/lib/tools";

export default function BestAiReceptionistForHvac() {
  const picks = getRecommendedTools("hvac", "ai-receptionist");

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Best AI receptionist for HVAC</div>
          <h1>Best AI Receptionist Tools for HVAC Companies</h1>
          <p className="lead">Compare AI answering tools for seasonal surges, emergency calls, and booked HVAC jobs.</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> For HVAC companies, the best AI receptionist should handle after-hours emergency calls, seasonal call spikes, and clean handoffs into dispatch or CRM workflows.
          </div>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {picks.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
          <div style={{ marginTop: 16 }}><AffiliateDisclosure /></div>
        </div>
      </section>
    </main>
  );
}
