import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: "LocalStack AI — Revenue Recovery Tools for Home Services",
  description: "Search AI receptionists, missed-call text-back tools, CRMs, review platforms, and follow-up software for home service businesses."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <Header />
        {children}
        <footer className="footer">
          <div className="container">
            <strong>LocalStack AI:</strong> Public tool intelligence database + private affiliate layer for home-service revenue recovery. <a href="/how-we-make-money">How we make money</a> · <a href="/how-we-score">How we score tools</a>
          </div>
        </footer>
      </body>
    </html>
  );
}
