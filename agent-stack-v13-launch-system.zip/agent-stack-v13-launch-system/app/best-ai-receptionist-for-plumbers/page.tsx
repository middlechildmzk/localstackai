import { ToolCard } from "@/components/ToolCard";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { getRecommendedTools } from "@/lib/tools";

export default function BestAiReceptionistForPlumbers() {
  const picks = getRecommendedTools("plumbers", "ai-receptionist");

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Best AI receptionist for plumbers</div>
          <h1>Best AI Receptionist Tools for Plumbers</h1>
          <p className="lead">Compare AI answering tools that help plumbing companies capture emergency calls, after-hours leads, and booking requests.</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> For plumbers, the best AI receptionist depends on call volume, need for human backup, and emergency routing. Start with a tool that captures after-hours calls and routes leads into a CRM or booking workflow.
          </div>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {picks.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
          <div style={{ marginTop: 16 }}><AffiliateDisclosure /></div>
        </div>
      </section>
    </main>
  );
}
