import Link from "next/link";
import { notFound } from "next/navigation";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { JsonLd } from "@/components/JsonLd";
import { breadcrumbJsonLd, toolJsonLd } from "@/lib/seo";
import { getTool, siteUrl, tools } from "@/lib/tools";

export function generateStaticParams() {
  return tools.map((tool) => ({ slug: tool.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const tool = getTool(slug);
  if (!tool) return {};
  return {
    title: `${tool.name} Review for Home Services | LocalStack AI`,
    description: tool.answerBox,
    alternates: { canonical: `/tools/${tool.slug}` }
  };
}

export default async function ToolPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const tool = getTool(slug);
  if (!tool) notFound();

  const alternatives = tool.alternatives
    .map((alt) => getTool(alt))
    .filter(Boolean);

  return (
    <main>
      <JsonLd data={toolJsonLd(tool)} />
      <JsonLd
        data={breadcrumbJsonLd([
          { name: "Home", url: siteUrl },
          { name: "Tools", url: `${siteUrl}/tools` },
          { name: tool.name, url: `${siteUrl}/tools/${tool.slug}` }
        ])}
      />

      <section className="hero">
        <div className="container">
          <div className="eyebrow">/tools/{tool.slug}</div>
          <h1>{tool.name}</h1>
          <p className="lead">{tool.tagline}</p>
          <div className="hero-actions">
            <Link className="btn primary" href={`/go/${tool.slug}?source=tool-page`} rel="sponsored nofollow">Check Current Pricing</Link>
            <Link className="btn" href="/tools">Back to Tools</Link>
          </div>
          <p className="small muted">Disclosure: {tool.affiliateDisclosureLabel}</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> {tool.answerBox}
          </div>
        </div>
      </section>

      <section>
        <div className="container profile-grid">
          <div className="card">
            <h3>Best for</h3>
            <div className="badges">{tool.bestForTags.map((tag) => <span key={tag} className="badge green">{tag}</span>)}</div>
            <h3 style={{ marginTop: 18 }}>Avoid if</h3>
            <p className="muted">{tool.avoidIf}</p>
          </div>

          <div className="card">
            <h3>Home-service fit</h3>
            <div className="badges">{tool.verticals.map((vertical) => <span key={vertical} className="badge blue">{vertical}</span>)}</div>
            <h3 style={{ marginTop: 18 }}>Setup difficulty</h3>
            <span className="badge warn">{tool.setupDifficulty}</span>
          </div>

          <div className="card">
            <h3>Features</h3>
            <div className="badges">{tool.features.map((feature) => <span key={feature} className="badge">{feature}</span>)}</div>
          </div>

          <div className="card">
            <h3>Integrations</h3>
            <div className="badges">{tool.integrations.map((integration) => <span key={integration} className="badge">{integration}</span>)}</div>
          </div>

          <div className="card">
            <h3>Pricing snapshot</h3>
            <p className="muted">{tool.pricingSummary}</p>
            <p className="small muted"><strong>{tool.pricingLastVerified}</strong></p>{tool.pricingSourceUrl && <p className="small"><a href={tool.pricingSourceUrl} target="_blank" rel="noreferrer">View pricing source</a></p>}
          </div>

          <div className="card">
            <h3>Alternatives</h3>
            <div className="badges">
              {alternatives.map((alt) => alt && <Link key={alt.slug} className="badge blue" href={`/tools/${alt.slug}`}>{alt.name}</Link>)}
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card">
            <h3>Evidence / source links</h3>
            <ul>
              {tool.evidenceLinks.map((link) => (
                <li key={link.url}><a href={link.url} target="_blank" rel="noreferrer">{link.label}</a></li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section>
        <div className="container grid2">
          <AffiliateDisclosure />
          <div className="card warning">
            <h2>Not sure this fits your current stack?</h2>
            <p>Book a 15-minute Stack Audit and get a practical recommendation for your phone, CRM, review, and follow-up workflow.</p>
            <a className="btn primary" href="/audit">Book the $99 Stack Audit</a>
          </div>
        </div>
      </section>
    </main>
  );
}
