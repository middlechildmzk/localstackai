import { ToolCard } from "@/components/ToolCard";
import { JsonLd } from "@/components/JsonLd";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { categories, siteUrl, tools } from "@/lib/tools";
import { itemListJsonLd, breadcrumbJsonLd } from "@/lib/seo";

export default function ToolsPage({
  searchParams
}: {
  searchParams?: Promise<{ category?: string; vertical?: string; q?: string }>;
}) {
  // Next 16 may pass searchParams as a Promise in some configs.
  // This page intentionally renders all tools for v1. Use client filtering later or query params in production.
  const listSchema = itemListJsonLd(
    tools.map((tool) => ({
      name: tool.name,
      url: `${siteUrl}/tools/${tool.slug}`,
      description: tool.description
    }))
  );

  return (
    <main>
      <JsonLd data={listSchema} />
      <JsonLd data={breadcrumbJsonLd([{ name: "Home", url: siteUrl }, { name: "Tools", url: `${siteUrl}/tools` }])} />

      <section className="hero">
        <div className="container">
          <div className="eyebrow">Tool database</div>
          <h1>Home Service AI Tool Database</h1>
          <p className="lead">Search AI receptionists, missed-call text-back tools, field service CRMs, review platforms, and phone systems.</p>
        </div>
      </section>

      <section>
        <div className="container">
          <AffiliateDisclosure />

          <div className="card" style={{ marginTop: 16 }}>
            <h3>Launch categories</h3>
            <div className="badges">
              {categories.map((category) => (
                <a key={category.slug} className="badge blue" href={`/categories/${category.slug}`}>
                  {category.name}
                </a>
              ))}
            </div>
          </div>

          <div className="tools-grid" style={{ marginTop: 16 }}>
            {tools.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
        </div>
      </section>
    </main>
  );
}
