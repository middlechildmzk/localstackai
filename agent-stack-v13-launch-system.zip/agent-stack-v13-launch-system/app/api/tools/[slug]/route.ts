import { NextResponse } from "next/server";
import { getTool } from "@/lib/tools";

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const tool = getTool(slug);

  if (!tool) {
    return NextResponse.json({ error: "Tool not found" }, { status: 404 });
  }

  // Public-safe response only. Do not include raw affiliate URLs or payout terms here.
  return NextResponse.json({
    slug: tool.slug,
    name: tool.name,
    category: tool.category,
    category_label: tool.categoryLabel,
    description: tool.description,
    answer_box: tool.answerBox,
    verticals: tool.verticals,
    best_for_tags: tool.bestForTags,
    integrations: tool.integrations,
    pricing_summary: tool.pricingSummary,
    pricing_last_verified: tool.pricingLastVerified,
    setup_difficulty: tool.setupDifficulty,
    evidence_links: tool.evidenceLinks,
    alternatives: tool.alternatives,
    affiliate_disclosure: tool.affiliateDisclosureLabel
  });
}
