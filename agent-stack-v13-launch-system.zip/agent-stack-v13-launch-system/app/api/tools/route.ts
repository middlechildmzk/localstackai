import { NextResponse } from "next/server";
import { tools } from "@/lib/tools";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");
  const vertical = searchParams.get("vertical");
  const q = searchParams.get("q")?.toLowerCase();

  const filtered = tools.filter((tool) => {
    if (category && tool.category !== category) return false;
    if (vertical && !tool.verticals.includes(vertical as any) && !tool.verticals.includes("all")) return false;
    if (q) {
      const haystack = [
        tool.name,
        tool.categoryLabel,
        tool.description,
        tool.bestForTags.join(" "),
        tool.integrations.join(" "),
        tool.features.join(" ")
      ].join(" ").toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  return NextResponse.json({
    tools: filtered.map((tool) => ({
      slug: tool.slug,
      name: tool.name,
      category: tool.category,
      category_label: tool.categoryLabel,
      verticals: tool.verticals,
      best_for_tags: tool.bestForTags,
      pricing_summary: tool.pricingSummary,
      setup_difficulty: tool.setupDifficulty,
      description: tool.description
    }))
  });
}
