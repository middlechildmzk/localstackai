import { NextResponse } from "next/server";
import { captureLead } from "@/lib/tracking";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = String(body.email || "").trim();

    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "Valid email required" }, { status: 400 });
    }

    const result = await captureLead({
      email,
      businessType: body.businessType,
      biggestPain: body.biggestPain,
      currentTools: body.currentTools,
      monthlyBudget: body.monthlyBudget,
      source: body.source,
      recommendedStack: body.recommendedStack
    });

    return NextResponse.json({ ok: true, mode: result.mode });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to capture lead" }, { status: 500 });
  }
}
