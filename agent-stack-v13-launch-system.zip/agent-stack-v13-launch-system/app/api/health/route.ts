import { NextResponse } from "next/server";
import { tools, categories, verticals } from "@/lib/tools";

export async function GET() {
  return NextResponse.json({
    ok: true,
    version: "1.3.0",
    checkedAt: new Date().toISOString(),
    counts: {
      tools: tools.length,
      categories: categories.length,
      verticals: verticals.length
    }
  });
}
