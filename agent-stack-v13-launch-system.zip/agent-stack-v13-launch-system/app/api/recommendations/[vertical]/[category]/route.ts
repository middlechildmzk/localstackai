import { NextResponse } from "next/server";
import { recommendationFor } from "@/lib/recommendations";

export async function GET(
  _: Request,
  { params }: { params: Promise<{ vertical: string; category: string }> }
) {
  const { vertical, category } = await params;
  return NextResponse.json(recommendationFor(vertical, category));
}
