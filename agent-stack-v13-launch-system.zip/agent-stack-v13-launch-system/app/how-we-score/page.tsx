export default function HowWeScorePage() {
  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Trust</div>
          <h1>How We Recommend Tools</h1>
          <p className="lead">LocalStack AI ranks tools by home-service fit, revenue-recovery use case, setup difficulty, integration depth, pricing clarity, and evidence quality.</p>
        </div>
      </section>

      <section>
        <div className="container grid2">
          <div className="card">
            <h2>Public recommendation factors</h2>
            <ul>
              <li>Does it help answer more calls?</li>
              <li>Does it help recover missed leads?</li>
              <li>Does it route leads into booking or CRM?</li>
              <li>Is setup realistic for a busy owner?</li>
              <li>Are pricing and integrations clear?</li>
              <li>Is there public evidence or official documentation?</li>
            </ul>
          </div>

          <div className="card warning">
            <h2>What we avoid</h2>
            <ul>
              <li>No fake star ratings.</li>
              <li>No hidden pay-to-win rankings.</li>
              <li>No unsupported revenue guarantees.</li>
              <li>No public exposure of private affiliate terms.</li>
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}
