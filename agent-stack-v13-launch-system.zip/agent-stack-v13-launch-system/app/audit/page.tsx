export default function AuditPage() {
  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Stack Audit</div>
          <h1>Get a $99 Revenue Recovery Stack Audit.</h1>
          <p className="lead">We review your current phone, booking, CRM, review, and follow-up setup and send a simple recommendation for what to install first.</p>
          <div className="hero-actions">
            <a className="btn primary" href="mailto:dllarson1991@gmail.com?subject=LocalStack%20AI%20Stack%20Audit">Request Audit</a>
            <a className="btn" href="/for-plumbers">See plumber stack</a>
          </div>
        </div>
      </section>

      <section>
        <div className="container grid">
          <div className="card"><h3>What we review</h3><p>Your phone setup, missed-call handling, booking process, CRM, review requests, and follow-up workflow.</p></div>
          <div className="card"><h3>What you get</h3><p>A recommended 2–4 tool stack, setup order, estimated monthly cost, and what to avoid.</p></div>
          <div className="card"><h3>Who it is for</h3><p>Plumbers and HVAC operators who want a practical recommendation without researching software for hours.</p></div>
        </div>
      </section>
    </main>
  );
}
