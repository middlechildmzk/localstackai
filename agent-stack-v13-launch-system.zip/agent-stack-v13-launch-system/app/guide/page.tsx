export default function GuidePage() {
  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Launch offer</div>
          <h1>The 2026 Revenue Recovery Blueprint</h1>
          <p className="lead">A practical setup guide for plumbers and HVAC companies that want to stop losing jobs to missed calls, slow follow-up, and messy booking workflows.</p>
          <div className="hero-actions">
            <a className="btn primary" href="#">Get the $49 Guide</a>
            <a className="btn" href="/for-plumbers">Preview the stack</a>
          </div>
        </div>
      </section>

      <section>
        <div className="container grid">
          <div className="card"><h3>Call recovery stack</h3><p>What to install first if you miss calls during jobs, weekends, or after hours.</p></div>
          <div className="card"><h3>Booking handoff</h3><p>How to route recovered leads into CRM, scheduling, and follow-up.</p></div>
          <div className="card"><h3>Review growth</h3><p>How to automate review requests after completed jobs.</p></div>
        </div>
      </section>
    </main>
  );
}
