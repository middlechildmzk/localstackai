import { ToolCard } from "@/components/ToolCard";
import { AffiliateDisclosure } from "@/components/AffiliateDisclosure";
import { getRecommendedTools } from "@/lib/tools";

export default function BestCrmForHvac() {
  const picks = getRecommendedTools("hvac", "field-service-crm");

  return (
    <main>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Best CRM for HVAC</div>
          <h1>Best Field Service CRM Tools for HVAC Companies</h1>
          <p className="lead">Compare HVAC CRM tools for scheduling, dispatch, booking handoff, payments, and revenue recovery.</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card answer" id="ai-summary">
            <strong>Answer Box:</strong> HVAC companies should choose a CRM based on crew size, dispatch complexity, seasonal call volume, and booking handoff needs. Jobber and Housecall Pro are simpler starting points, while ServiceTitan is typically a larger-operator platform.
          </div>
          <div className="tools-grid" style={{ marginTop: 16 }}>
            {picks.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
          </div>
          <div style={{ marginTop: 16 }}><AffiliateDisclosure /></div>
        </div>
      </section>
    </main>
  );
}
