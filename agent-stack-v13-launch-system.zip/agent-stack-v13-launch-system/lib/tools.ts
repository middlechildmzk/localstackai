import type { Category, Tool, Vertical } from "./types";

export const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const categories: Category[] = [
  { slug: "ai-receptionist", name: "AI Receptionist", description: "24/7 call answering, lead intake, emergency routing, and booking support.", priority: "High" },
  { slug: "missed-call-text", name: "Missed Call Text-Back", description: "Automatically text leads when you miss a call and route them into follow-up.", priority: "High" },
  { slug: "field-service-crm", name: "Field Service CRM", description: "Scheduling, dispatch, payments, customer records, and job management.", priority: "High" },
  { slug: "review-automation", name: "Review Automation", description: "Request reviews and build local trust after completed jobs.", priority: "Medium" },
  { slug: "voip-phone", name: "Business Phone / VoIP", description: "Smart phone systems for teams, crews, and shared business numbers.", priority: "Medium" }
];

export const verticals: Vertical[] = [
  { slug: "plumbers", name: "Plumbers", averageJobValueDefault: 650, description: "Plumbing companies need fast call capture for emergency repairs, estimates, and recurring service." },
  { slug: "hvac", name: "HVAC", averageJobValueDefault: 900, description: "HVAC companies need after-hours call capture, seasonal surge coverage, and booking handoff." },
  { slug: "roofers", name: "Roofers", averageJobValueDefault: 2500, description: "Roofers need fast response for storm, leak, and estimate requests." },
  { slug: "electricians", name: "Electricians", averageJobValueDefault: 500, description: "Electricians need call capture for urgent jobs, service scheduling, and follow-up." },
  { slug: "cleaners", name: "Cleaners", averageJobValueDefault: 250, description: "Cleaning businesses need quote response, repeat booking, and review generation." }
];

const checked = "Last checked May 11, 2026";

export const tools: Tool[] = [
  {
    name: "Smith.ai",
    slug: "smith-ai",
    initials: "SA",
    category: "ai-receptionist",
    categoryLabel: "AI Receptionist",
    tagline: "AI and human receptionist support for call answering and lead intake.",
    description: "AI and human receptionist service for businesses that need call answering, intake, scheduling, and lead qualification.",
    answerBox: "Smith.ai may fit plumbing and electrical businesses that want a hybrid AI plus human answering layer. It is most useful when missed calls and intake quality matter more than the cheapest possible tool.",
    websiteUrl: "https://smith.ai/",
    pricingSummary: "AI Receptionist plans start at $95/mo; higher-volume AI plans and human receptionist options cost more.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://smith.ai/pricing/ai-receptionist",
    isVerified: true,
    setupDifficulty: "Medium",
    integrations: ["Zapier", "Calendly", "HubSpot", "Google Calendar"],
    bestForTags: ["hybrid human/AI support", "lead qualification", "after-hours calls"],
    verticals: ["plumbers", "electricians", "hvac"],
    features: ["AI answering", "Human backup", "Call intake", "Call routing", "Appointment booking"],
    avoidIf: "You only need a very cheap missed-call text-back tool.",
    evidenceLinks: [
      { label: "Official AI Receptionist pricing", url: "https://smith.ai/pricing/ai-receptionist", type: "pricing" },
      { label: "Official website", url: "https://smith.ai/", type: "official" }
    ],
    alternatives: ["ruby", "openphone", "callrail"],
    publicBadges: ["Human backup", "After-hours", "Lead intake"],
    partnerStatus: "apply",
    affiliateDisclosureLabel: "We may earn a commission if you sign up through our links."
  },
  {
    name: "Ruby",
    slug: "ruby",
    initials: "R",
    category: "ai-receptionist",
    categoryLabel: "AI Receptionist",
    tagline: "Premium virtual receptionist and call-answering experience.",
    description: "Virtual receptionist service for businesses that want live call handling, a polished brand experience, and call overflow support.",
    answerBox: "Ruby may fit HVAC and plumbing businesses that care about a premium live receptionist experience. It may be less ideal for owners who want the lowest-cost AI-only workflow.",
    websiteUrl: "https://www.ruby.com/",
    pricingSummary: "Ruby help docs list Call Ruby 50 at $250/mo for 50 receptionist minutes; official plan pages may show bundled variants.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://rubyhelpcenter.helpjuice.com/billing-plans/am-i-on-the-right-billing-plan",
    isVerified: true,
    setupDifficulty: "Hard",
    integrations: ["Jobber", "Salesforce"],
    bestForTags: ["premium brand experience", "live reception", "call overflow"],
    verticals: ["hvac", "plumbers"],
    features: ["Live answering", "Call routing", "Message taking", "Scheduling support"],
    avoidIf: "You want a self-serve AI-only tool with minimal setup.",
    evidenceLinks: [
      { label: "Ruby help center billing plans", url: "https://rubyhelpcenter.helpjuice.com/billing-plans/am-i-on-the-right-billing-plan", type: "pricing" },
      { label: "Official website", url: "https://www.ruby.com/", type: "official" }
    ],
    alternatives: ["smith-ai", "openphone"],
    publicBadges: ["Premium brand feel", "Live reception"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  },
  {
    name: "Podium",
    slug: "podium",
    initials: "P",
    category: "review-automation",
    categoryLabel: "Review Automation",
    tagline: "Messaging, reviews, and customer communication for local businesses.",
    description: "Messaging and reputation platform for local businesses that need SMS follow-up, reviews, and customer communication.",
    answerBox: "Podium may fit home-service businesses that need SMS messaging, review generation, and customer follow-up. It is often a retention and reputation layer rather than a single-purpose AI receptionist.",
    websiteUrl: "https://www.podium.com/",
    pricingSummary: "Quote-based / contact sales on Podium’s official pricing page; third-party pricing reports vary.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.podium.com/getpricing",
    isVerified: true,
    setupDifficulty: "Medium",
    integrations: ["Jobber", "ServiceTitan", "QuickBooks"],
    bestForTags: ["review growth", "text messaging", "lead recovery"],
    verticals: ["all"],
    features: ["Reviews", "SMS messaging", "Payments", "Webchat"],
    avoidIf: "You only need basic call answering or low-cost review request templates.",
    evidenceLinks: [
      { label: "Official pricing/contact page", url: "https://www.podium.com/getpricing", type: "pricing" },
      { label: "Official website", url: "https://www.podium.com/", type: "official" }
    ],
    alternatives: ["nicejob", "callrail"],
    publicBadges: ["Reviews + SMS", "Local reputation"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  },
  {
    name: "NiceJob",
    slug: "nicejob",
    initials: "NJ",
    category: "review-automation",
    categoryLabel: "Review Automation",
    tagline: "Review generation and reputation marketing for service businesses.",
    description: "NiceJob helps businesses request reviews, showcase social proof, and improve reputation marketing.",
    answerBox: "NiceJob may fit cleaning, roofing, plumbing, and HVAC businesses that want simple review automation and social proof. It is a strong reputation layer after call capture is working.",
    websiteUrl: "https://nicejob.com/",
    pricingSummary: "NiceJob promotes a free trial; verify current paid plan pricing directly before quoting exact monthly cost.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://get.nicejob.com/",
    isVerified: true,
    setupDifficulty: "Easy",
    integrations: ["Jobber", "Housecall Pro", "Zapier"],
    bestForTags: ["easy review requests", "social proof", "review automation"],
    verticals: ["plumbers", "hvac", "roofers", "cleaners"],
    features: ["Review requests", "Social proof", "Website widgets", "Campaigns"],
    avoidIf: "You need a full messaging/payment/reputation suite.",
    evidenceLinks: [
      { label: "Official NiceJob website", url: "https://get.nicejob.com/", type: "official" },
      { label: "NiceJob integrations / partners", url: "https://partners.nicejob.com/integrations", type: "docs" }
    ],
    alternatives: ["podium"],
    publicBadges: ["Easy reviews", "Works with Jobber"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  },
  {
    name: "Jobber",
    slug: "jobber",
    initials: "J",
    category: "field-service-crm",
    categoryLabel: "Field Service CRM",
    tagline: "Scheduling, quotes, invoices, and client management for home service businesses.",
    description: "Jobber helps small home-service teams manage quoting, scheduling, invoices, payments, and customer communication.",
    answerBox: "Jobber is a strong starter CRM for small home-service teams that need scheduling, quotes, invoices, and customer follow-up. It is often a better second step after fixing missed calls because it gives recovered leads somewhere to go.",
    websiteUrl: "https://getjobber.com/",
    pricingSummary: "Core starts at $49/mo month-to-month; annual or promotional pricing may be lower.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.getjobber.com/pricing/",
    isVerified: true,
    setupDifficulty: "Easy",
    integrations: ["Stripe", "QuickBooks", "Mailchimp", "Zapier"],
    bestForTags: ["ease of use", "mobile invoicing", "small crews"],
    verticals: ["cleaners", "electricians", "plumbers", "hvac"],
    features: ["Scheduling", "Quotes", "Invoices", "Payments", "Client hub"],
    avoidIf: "You only need call answering and are not ready for a CRM.",
    evidenceLinks: [
      { label: "Official pricing page", url: "https://www.getjobber.com/pricing/", type: "pricing" },
      { label: "Official website", url: "https://getjobber.com/", type: "official" }
    ],
    alternatives: ["housecall-pro", "servicetitan"],
    publicBadges: ["Best all-around", "Easy setup", "Small crews"],
    partnerStatus: "apply",
    affiliateDisclosureLabel: "We may earn a commission if you sign up through our links."
  },
  {
    name: "Housecall Pro",
    slug: "housecall-pro",
    initials: "HP",
    category: "field-service-crm",
    categoryLabel: "Field Service CRM",
    tagline: "Home service software for scheduling, dispatch, payments, reviews, and marketing.",
    description: "Home service software for scheduling, dispatching, estimates, payments, reviews, and marketing workflows.",
    answerBox: "Housecall Pro may fit plumbing, HVAC, and roofing companies that need a mid-market operating system for booking, dispatch, payments, reviews, and marketing.",
    websiteUrl: "https://www.housecallpro.com/",
    pricingSummary: "Official pricing page says plans start from $59/mo; billing and plan details vary.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.housecallpro.com/pricing/",
    isVerified: true,
    setupDifficulty: "Medium",
    integrations: ["Google Local Services Ads", "QuickBooks", "Google Calendar", "Zapier"],
    bestForTags: ["integrated marketing", "booking", "mid-market growth"],
    verticals: ["plumbers", "hvac", "roofers"],
    features: ["Scheduling", "Dispatch", "Payments", "Reviews", "Marketing"],
    avoidIf: "You want a single-purpose phone tool and are not ready to change operations.",
    evidenceLinks: [
      { label: "Official pricing page", url: "https://www.housecallpro.com/pricing/", type: "pricing" },
      { label: "Official website", url: "https://www.housecallpro.com/", type: "official" }
    ],
    alternatives: ["jobber", "servicetitan"],
    publicBadges: ["Mid-market growth", "Booking + payments"],
    partnerStatus: "apply",
    affiliateDisclosureLabel: "We may earn a commission if you sign up through our links."
  },
  {
    name: "ServiceTitan",
    slug: "servicetitan",
    initials: "ST",
    category: "field-service-crm",
    categoryLabel: "Field Service CRM",
    tagline: "Enterprise-grade operating system for larger home-service companies.",
    description: "Field service platform for larger contractors that need dispatch, CRM, reporting, call booking, and operations management.",
    answerBox: "ServiceTitan is typically a fit for larger HVAC and plumbing operations that need robust dispatch workflows, reporting, call booking, and operational controls. Smaller operators may want a lighter CRM before considering it.",
    websiteUrl: "https://www.servicetitan.com/",
    pricingSummary: "Quote-based / request pricing. Best evaluated directly for larger operations.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.servicetitan.com/pricing",
    isVerified: true,
    setupDifficulty: "Hard",
    integrations: ["Direct GPS", "Inventory Systems", "Call booking"],
    bestForTags: ["enterprise reporting", "large fleets", "dispatch-heavy operations"],
    verticals: ["hvac", "plumbers"],
    features: ["Dispatch", "CRM", "Reporting", "Call booking", "Marketing"],
    avoidIf: "You are a one-truck operator needing a fast, low-cost setup.",
    evidenceLinks: [
      { label: "Official pricing request page", url: "https://www.servicetitan.com/pricing", type: "pricing" },
      { label: "Official website", url: "https://www.servicetitan.com/", type: "official" }
    ],
    alternatives: ["jobber", "housecall-pro"],
    publicBadges: ["Enterprise ops", "Large fleets"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  },
  {
    name: "CallRail",
    slug: "callrail",
    initials: "CR",
    category: "missed-call-text",
    categoryLabel: "Missed Call Text-Back",
    tagline: "Call tracking, lead attribution, and AI voice assist for missed-call visibility.",
    description: "CallRail helps businesses track calls, understand lead sources, and improve phone-driven marketing workflows.",
    answerBox: "CallRail may fit plumbers and HVAC companies that need to understand which marketing sources drive calls and which calls are being missed. Its Voice Assist option can also help capture qualified leads after hours.",
    websiteUrl: "https://www.callrail.com/",
    pricingSummary: "Lead Tracking starts at $55/mo; Voice Assist starts at $95/mo and requires Lead Tracking.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.callrail.com/pricing",
    isVerified: true,
    setupDifficulty: "Medium",
    integrations: ["Google Ads", "Google Analytics", "HubSpot", "Zapier"],
    bestForTags: ["call tracking", "lead attribution", "missed-call visibility"],
    verticals: ["plumbers", "hvac"],
    features: ["Call tracking", "Lead attribution", "Call recordings", "Voice Assist"],
    avoidIf: "You need a human receptionist or full field-service CRM rather than call intelligence.",
    evidenceLinks: [
      { label: "Official pricing page", url: "https://www.callrail.com/pricing", type: "pricing" },
      { label: "Voice Assist overview", url: "https://www.callrail.com/voice-assist", type: "docs" }
    ],
    alternatives: ["openphone", "smith-ai"],
    publicBadges: ["Call tracking", "Voice Assist", "Attribution"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  },
  {
    name: "Quo / OpenPhone",
    slug: "openphone",
    initials: "OP",
    category: "voip-phone",
    categoryLabel: "Business Phone / VoIP",
    tagline: "Shared business phone numbers and team communication for small crews.",
    description: "Quo, formerly OpenPhone, is a business phone system for teams that want shared numbers, texting, call history, and collaboration.",
    answerBox: "Quo / OpenPhone may fit small crews that need a professional shared number, texting, and call organization. It is a strong phone layer but may need other tools for AI answering, CRM, and booking workflows.",
    websiteUrl: "https://www.quo.com/",
    pricingSummary: "Starter is listed at $15/user/mo annually or $19/user/mo monthly.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.quo.com/pricing",
    isVerified: true,
    setupDifficulty: "Easy",
    integrations: ["Zapier", "Google Workspace", "HubSpot", "Slack"],
    bestForTags: ["shared team numbers", "small crews", "texting"],
    verticals: ["all"],
    features: ["Business phone", "Shared inbox", "SMS", "Call history"],
    avoidIf: "You need an AI receptionist to answer and triage calls automatically.",
    evidenceLinks: [
      { label: "Official Quo pricing", url: "https://www.quo.com/pricing", type: "pricing" },
      { label: "Quo support pricing notes", url: "https://support.quo.com/core-concepts/administration/billing/pricing", type: "docs" }
    ],
    alternatives: ["callrail", "smith-ai"],
    publicBadges: ["Shared number", "Small crews"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  },
  {
    name: "LeadConnector / GoHighLevel",
    slug: "gohighlevel",
    initials: "GHL",
    category: "missed-call-text",
    categoryLabel: "Missed Call Text-Back",
    tagline: "Marketing automation, missed-call text-back, funnels, and CRM workflows.",
    description: "GoHighLevel-style workflows are often used by agencies and operators for missed-call text-back, SMS/email follow-up, funnels, and local business automation.",
    answerBox: "LeadConnector / GoHighLevel-style workflows may fit plumbing and HVAC businesses with active paid lead flow and a need for SMS nurture. It is best when someone can configure automations correctly.",
    websiteUrl: "https://www.gohighlevel.com/",
    pricingSummary: "Agency Starter is $97/mo; email/SMS/phone usage and other add-ons can create extra costs.",
    pricingLastVerified: checked,
    pricingSourceUrl: "https://www.gohighlevel.com/pricing",
    isVerified: true,
    setupDifficulty: "Hard",
    integrations: ["Twilio", "Stripe", "Zapier", "Calendars"],
    bestForTags: ["missed-call text-back", "automation-heavy setup", "agency workflows"],
    verticals: ["all"],
    features: ["Missed-call text-back", "SMS/email follow-up", "Funnels", "CRM", "Automations"],
    avoidIf: "You want a simple out-of-the-box phone answering tool without setup work.",
    evidenceLinks: [
      { label: "Official pricing page", url: "https://www.gohighlevel.com/pricing", type: "pricing" },
      { label: "HighLevel pricing/billing help", url: "https://help.gohighlevel.com/support/solutions/articles/155000001156-highlevel-pricing-guide", type: "docs" }
    ],
    alternatives: ["podium", "callrail"],
    publicBadges: ["Automation-heavy", "Text-back"],
    partnerStatus: "research",
    affiliateDisclosureLabel: "Partner status needs verification."
  }
];

export function getTool(slug: string) {
  return tools.find((tool) => tool.slug === slug);
}

export function getCategory(slug: string) {
  return categories.find((category) => category.slug === slug);
}

export function getToolsByCategory(slug: string) {
  return tools.filter((tool) => tool.category === slug);
}

export function getToolsByVertical(vertical: string) {
  return tools.filter((tool) => tool.verticals.includes(vertical as any) || tool.verticals.includes("all"));
}

export function getRecommendedTools(vertical: string, category: string) {
  const matching = tools.filter(
    (tool) =>
      tool.category === category &&
      (tool.verticals.includes(vertical as any) || tool.verticals.includes("all"))
  );

  return matching.slice(0, 5);
}
