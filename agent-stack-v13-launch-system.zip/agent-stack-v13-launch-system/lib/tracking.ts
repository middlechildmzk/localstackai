import { getSupabaseServiceClient } from "./supabaseServer";

export async function logOutboundClick(input: {
  toolSlug: string;
  verticalContext?: string;
  sourcePage?: string | null;
  referrer?: string | null;
  userAgent?: string | null;
  utmSource?: string | null;
  utmMedium?: string | null;
  utmCampaign?: string | null;
}) {
  const supabase = getSupabaseServiceClient();
  if (!supabase) {
    console.log("Supabase not configured. Outbound click:", input);
    return { ok: true, mode: "console" };
  }

  const { data: tool } = await supabase
    .from("tools")
    .select("id, slug")
    .eq("slug", input.toolSlug)
    .maybeSingle();

  const { error } = await supabase.from("outbound_clicks").insert({
    tool_id: tool?.id ?? null,
    vertical_context: input.verticalContext ?? "general",
    source_page: input.sourcePage ?? null,
    referrer: input.referrer ?? null,
    user_agent: input.userAgent ?? null,
    utm_source: input.utmSource ?? null,
    utm_medium: input.utmMedium ?? null,
    utm_campaign: input.utmCampaign ?? null
  });

  if (error) {
    console.error("Failed to log outbound click", error);
    return { ok: false, error };
  }

  return { ok: true, mode: "supabase" };
}

export async function captureLead(input: {
  email: string;
  businessType?: string;
  biggestPain?: string;
  currentTools?: string[];
  monthlyBudget?: string;
  source?: string;
  recommendedStack?: unknown;
}) {
  const supabase = getSupabaseServiceClient();
  if (!supabase) {
    console.log("Supabase not configured. Lead capture:", input);
    return { ok: true, mode: "console" };
  }

  const { error } = await supabase.from("quiz_leads").insert({
    email: input.email,
    business_type: input.businessType ?? null,
    biggest_pain: input.biggestPain ?? null,
    current_tools: input.currentTools ?? [],
    monthly_budget: input.monthlyBudget ?? null,
    recommended_stack_json: {
      source: input.source ?? "unknown",
      recommendation: input.recommendedStack ?? null
    }
  });

  if (error) {
    console.error("Failed to capture lead", error);
    return { ok: false, error };
  }

  return { ok: true, mode: "supabase" };
}
