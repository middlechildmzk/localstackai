export type SetupDifficulty = "Easy" | "Medium" | "Hard";

export type ToolCategorySlug =
  | "ai-receptionist"
  | "missed-call-text"
  | "field-service-crm"
  | "review-automation"
  | "voip-phone"
  | "scheduling"
  | "website-chatbot"
  | "automation"
  | "field-documentation"
  | "estimating"
  | "financing";

export type VerticalSlug =
  | "plumbers"
  | "hvac"
  | "roofers"
  | "electricians"
  | "cleaners"
  | "all";

export type EvidenceLink = {
  label: string;
  url: string;
  type?: "official" | "pricing" | "docs" | "review" | "manual";
};

export type Tool = {
  name: string;
  slug: string;
  initials: string;
  category: ToolCategorySlug;
  categoryLabel: string;
  description: string;
  tagline: string;
  answerBox: string;
  websiteUrl: string;
  pricingSummary: string;
  pricingLastVerified: string;
  pricingSourceUrl?: string;
  isVerified?: boolean;
  isDraft?: boolean;
  setupDifficulty: SetupDifficulty;
  integrations: string[];
  bestForTags: string[];
  verticals: VerticalSlug[];
  features: string[];
  avoidIf: string;
  evidenceLinks: EvidenceLink[];
  alternatives: string[];
  publicBadges: string[];
  partnerStatus: "active" | "apply" | "research" | "unavailable";
  affiliateDisclosureLabel: string;
};

export type Category = {
  slug: ToolCategorySlug;
  name: string;
  description: string;
  priority: "High" | "Medium" | "Low";
};

export type Vertical = {
  slug: Exclude<VerticalSlug, "all">;
  name: string;
  averageJobValueDefault: number;
  description: string;
};
