import { getRecommendedTools, tools } from "./tools";

export function recommendationFor(vertical: string, category: string) {
  const matches = getRecommendedTools(vertical, category);

  const topPick = matches[0] || tools.find((tool) => tool.category === category) || tools[0];
  const runnerUp = matches[1] || null;
  const budgetPick =
    matches.find((tool) => tool.setupDifficulty === "Easy") || matches[2] || null;

  return {
    vertical,
    category,
    top_pick: topPick
      ? {
          slug: topPick.slug,
          name: topPick.name,
          reason: topPick.answerBox
        }
      : null,
    runner_up: runnerUp
      ? {
          slug: runnerUp.slug,
          name: runnerUp.name,
          reason: runnerUp.answerBox
        }
      : null,
    budget_pick: budgetPick
      ? {
          slug: budgetPick.slug,
          name: budgetPick.name,
          reason: `A lower-friction option because setup difficulty is ${budgetPick.setupDifficulty}.`
        }
      : null
  };
}
