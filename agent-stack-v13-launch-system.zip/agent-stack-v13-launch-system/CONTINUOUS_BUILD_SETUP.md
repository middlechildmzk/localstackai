# Continuous Build / “While You Sleep” Setup

This repo cannot build itself unless it is connected to external infrastructure, but the project now includes GitHub Actions workflows that can run automatically.

## Best fast setup

1. Create a GitHub repo.
2. Push this project to `main`.
3. Connect the repo to Vercel.
4. Add environment variables in Vercel:
   - `NEXT_PUBLIC_SITE_URL`
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
5. GitHub Actions will run:
   - typecheck
   - build
   - data snapshot
6. The nightly workflow runs every day at 08:00 UTC.

## What it can do automatically

- Confirm the app still builds.
- Generate a public data snapshot artifact.
- Catch type/build failures.
- Trigger Vercel deployments when you push changes.

## What it cannot safely do yet

- Auto-write new SEO pages without review.
- Auto-verify pricing.
- Auto-publish affiliate claims.
- Auto-generate factual evidence from the web without source checks.

## Next automation upgrade

Add a `content_queue` table in Supabase:
- page_slug
- page_type
- target_vertical
- target_category
- status: draft | review | published
- evidence_needed
- assigned_priority

Then add a script that generates draft page files from approved tool/category data only.
