# LocalStack AI / Agent-Stack Deployment Runbook

## What still requires your accounts

This package prepares the code, schema, seed SQL, scripts, and launch assets. You must personally create/connect Supabase, Vercel, Stripe/Gumroad/Calendly because those require account access, billing/security choices, and secret keys.

## 1. Create Supabase project

1. Create a new Supabase project.
2. Save:
   - Project URL
   - anon/public key
   - service role key

Important: the service role key bypasses Row Level Security and must only be used server-side.

## 2. Run SQL

In Supabase SQL Editor, run:

1. `supabase/schema.sql`
2. `supabase/seed_launch_10.sql`

Confirm these tables exist:

- categories
- tools
- affiliate_data
- outbound_clicks
- quiz_leads
- calculator_events
- tool_search_events
- guide_purchases

## 3. Add env vars locally

Create `.env.local`:

```bash
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SUPABASE_URL=your-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

Run:

```bash
npm run verify-env
npm run build
npm run dev
```

## 4. Push to GitHub

```bash
git init
git add .
git commit -m "Launch LocalStack AI v1.3"
git branch -M main
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

## 5. Deploy to Vercel

1. Import the GitHub repo into Vercel.
2. Set framework as Next.js.
3. Add environment variables:
   - NEXT_PUBLIC_SITE_URL
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
   - SUPABASE_SERVICE_ROLE_KEY
4. Deploy.
5. Update `NEXT_PUBLIC_SITE_URL` to your real Vercel/custom domain URL.
6. Redeploy.

## 6. Payment links

Fastest path:
- Use Stripe Payment Links, Gumroad, or Lemon Squeezy for the $49 Blueprint.
- Use Calendly + Stripe/PayPal for the $99 Audit.

Replace placeholder links in:
- `/guide`
- `/audit`
- calculator success state
- tool sidebar CTA

## 7. QA before traffic

Open:

- /
- /tools
- /for-plumbers
- /for-hvac
- /tools/smith-ai
- /guide
- /audit
- /sitemap.xml
- /robots.txt
- /api/health
- /api/tools

Test:

- Calculator email capture inserts into `quiz_leads`.
- Tool CTA `/go/smith-ai` inserts into `outbound_clicks`.
- No console errors.
- Mobile card views are readable.
- Affiliate disclosure appears near CTAs.
