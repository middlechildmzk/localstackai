# Cursor / AI Dev Prompt — Build v1.4

You are upgrading LocalStack AI / Agent-Stack from v1.3 to v1.4.

Goal:
Move public tool data from hardcoded `lib/tools.ts` to Supabase-backed data fetching while preserving the same public routes and fallback behavior.

Requirements:
1. Keep `lib/tools.ts` as fallback if Supabase env vars are missing.
2. Add `lib/data/toolsRepository.ts`.
3. Fetch published tools from Supabase for:
   - `/tools`
   - `/tools/[slug]`
   - `/categories/[slug]`
   - `/api/tools`
   - `/api/tools/[slug]`
4. Do not expose `affiliate_data`.
5. Keep `/go/[slug]` server-only for affiliate destination lookup.
6. Maintain static generation if possible, but allow dynamic rendering where necessary.
7. Add robust error fallback.
8. Add tests or smoke checks for main routes.

Do not build:
- user accounts
- vendor portal
- public reviews
- auto-generated pages
