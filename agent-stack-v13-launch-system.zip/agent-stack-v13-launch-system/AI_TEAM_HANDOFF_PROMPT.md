# AI Team Handoff Prompt — Agent-Stack v1

You are reviewing the latest Agent-Stack / LocalStack AI v1 Next.js build.

## Context

We are building a public searchable tool database + recommendation engine for home-service revenue recovery.

Core wedge:
Missed calls = lost jobs.

Primary buyer:
Home service owners and operators, starting with plumbers and HVAC.

Public surfaces:
- `/tools`
- `/tools/[slug]`
- `/categories/[slug]`
- `/for-plumbers`
- `/for-hvac`
- `/best-ai-receptionist-for-plumbers`
- `/best-ai-receptionist-for-hvac`
- `/best-missed-call-text-back-for-plumbers`
- `/go/[slug]`
- `/api/tools`
- `/api/tools/[slug]`
- `/api/recommendations/[vertical]/[category]`

## Your task

Review the build for:

1. Product clarity
2. Buyer psychology
3. SEO/GEO readiness
4. Next.js architecture
5. Supabase schema readiness
6. Affiliate/privacy safety
7. Conversion flow
8. Tool data quality
9. Launch blockers
10. Fastest path to public launch

## Key questions

- Does `/tools` feel like a searchable data hub rather than a thin affiliate list?
- Do `/tools/[slug]` pages have enough unique value to be indexed?
- Are the Answer Box sections useful and safe?
- Which of the 25 tools should be removed or delayed until verification?
- Which 10 tools should be the true public launch set?
- What fields are missing from `lib/tools.ts`?
- What should be moved from hardcoded data into Supabase first?
- What are the highest-intent money pages to build next?
- Are any claims too strong or unsupported?
- How should the guide/audit/affiliate funnel be improved?

## Output format

Give:

1. Overall verdict
2. Launch blockers
3. Must-fix before publishing
4. Nice-to-have after launch
5. Tools to verify first
6. Suggested first 10 public tools
7. Suggested first 5 money pages
8. Recommended schema changes
9. Recommended copy changes
10. Final next 10 actions
